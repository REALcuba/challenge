// import React, { useState, useEffect } from 'react'

// function InfiniteScroll (response) {
//   const [cards, setCards] = useState([])
//   const [page, setPage] = useState(1)
//   const [loading, setLoading] = useState(false)

//   useEffect(() => {
//     fetchMoreItems()
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [])

//   const fetchMoreItems = () => {
//     setLoading(true)
//     // const data = await fetch(`https://your-api.com/items?page=${page}`)
//     // const newItems = await data.json()
//     const newItems = response.pageInfo.next
//     setItems([...items, ...newItems])
//     setPage(page + 1)
//     setLoading(false)
//   }

//   const handleScroll = () => {
//     if (
//       window.innerHeight + document.documentElement.scrollTop !==
//         document.documentElement.offsetHeight ||
//       loading
//     ) {
//       return
//     }
//     fetchMoreItems()
//   }

//   useEffect(() => {
//     window.addEventListener('scroll', handleScroll)
//     return () => window.removeEventListener('scroll', handleScroll)
//   })

//   return (
//     <>
//       <div>
//         {items.map((item) => (
//           <div key={item.id}>{item.name}</div>
//         ))}
//       </div>
//       {loading && <div>Loading...</div>}
//     </>
//   )
// }

// export default InfiniteScroll
