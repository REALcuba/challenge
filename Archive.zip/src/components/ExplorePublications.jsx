import React, { useEffect, useState } from 'react'

import { explorePublications } from '../lensQueries/explorePublications'
import PaintCardInfo from '../components/PaintCardInfo/PaintCardInfo'
import './style.css'

export default function ExplorePublications (props) {
  const [cards, setCards] = useState([])
  const [loading, setLoading] = useState(false)
  const [cursor, setCursor] = useState('{"timestamp":1,"offset":0}')
  // const [response, setResponse] = useState([])
  // const [page, setPage] = useState(1)

  const init = async () => {
    try {
      const request = {
        sortCriteria: 'LATEST', // You can filter by TOP_COMMENTED | TOP_COLLECTED | TOP_MIRRORED | LATEST
        noRandomize: true,
        sources: ['5bba5781-78b5-4927-8d2f-122742817583'],
        publicationTypes: ['POST'],
        cursor: { cursor },
        limit: 5
      }
      const response = await explorePublications(request) // To get next result replace the cursor with the value of response.pageInfo.next
      console.log(request)
      const responseArr = response.data.explorePublications.items
      console.log(cursor)
      setCursor(request.cursor)
      setCards([...cards, ...responseArr])
    } catch (err) {
      console.log(err)
    }
  }

  useEffect(() => {
    init()
  }, [])

  // const fetchMoreCards = async () => {
  //   console.log(loading)
  //   // memo(init)

  //   const newCards = await
  //   setLoading(false)
  //   // const data = await response
  //   // const newCards = cards
  //   console.log(newCards)
  //   return (
  //     setPage(cursor => cursor + 1),
  //     console.log(cursor),
  //     console.log('work'),
  //     console.log({ page }),
  //   )
  // }

  const handleScroll = async () => {
    setLoading(true)
    //     setCards([...cards, ...newCards])

    // setCursor(response.data.explorePublications.pageInfo.next)
    if (
      window.innerHeight + document.documentElement.scrollTop + 1 <=
      document.documentElement.offsetHeight
    ) {
      return
    }

    init()
    console.log(loading)
  }

  useEffect(() => {
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [cards, loading])

  return (

    <div className='container-fluid row bg-black m-0 justify-content-center'>

      {cards.map((card) => {
        // console.log(card)
        return (
          <div className='card p-0 m-1' key={card.id}>
            <PaintCardInfo key={card.id} onClick={handleScroll}>{card}</PaintCardInfo>
            {loading && <div>loading...</div>}
          </div>

        )
      })}
    </div>
  )
}
